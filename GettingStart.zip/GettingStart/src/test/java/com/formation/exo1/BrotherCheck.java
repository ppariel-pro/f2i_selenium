package com.formation.exo1;

import org.openqa.selenium.chrome.ChromeDriver;

public class BrotherCheck {
	
	public static void main(String[] args) throws InterruptedException {
		String chromeDriverPath = "C:\\temp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromeDriverPath);
		
		// ouvrir un navigateur chrome
		ChromeDriver chrome = new ChromeDriver();
		
		Thread.sleep(5000);
		chrome.quit();
	}

}
