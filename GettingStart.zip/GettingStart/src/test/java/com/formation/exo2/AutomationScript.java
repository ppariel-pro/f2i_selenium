package com.formation.exo2;

import org.openqa.selenium.chrome.ChromeDriver;

public class AutomationScript {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		String chromeDriverPath = "C:\\temp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromeDriverPath);

		// ouvrir un navigateur chrome
		ChromeDriver chrome = new ChromeDriver();

		// chargement d'une page
		chrome.get("http://www.google.com");

		if (chrome.getTitle().equalsIgnoreCase("google")) {
			System.out.println("OK Google");
		} else {
			System.out.println("not OK Google");

		}
		Thread.sleep(2000);

		chrome.navigate().to("http://www.bing.com");
		if (chrome.getTitle().equalsIgnoreCase("bing")) {
			System.out.println("OK Bing");
		} else {
			System.out.println("not OK Bing");

		}

		Thread.sleep(2000);

		chrome.navigate().back();

		Thread.sleep(2000);

		if (chrome.getTitle().equalsIgnoreCase("google")) {
			System.out.println("OK Google retour");
		} else {
			System.out.println("not OK Google ");
		}
		chrome.quit();
	}
}
