package com.formation.example2;

public class UneVoiture {
	String color = "Red";
	int power = 12;
	public String marque = "BMW";
	private String carburant = "essence";
//	constructeur param par default
public UneVoiture() {}
//constructeur parametrage avec affectation valeur 
public UneVoiture(String colora, int powera, String marquea) {
	//affectation variable 
	this.color = color;
	this.power = power;
	this.marque = marque;
}
public void start() {
	System.out.println("Car starting ...");
}

public void stop() {
	System.out.println("Car is stopping");
}

public int vitesse (int a ) {
	if ( a <=0 || a > 4) {
		return 0;
	}
	if (a == 1) return a * power * 2; 
	if (a == 2) {
		return a * power * 3;
	}
	
	if (a == 3) {
		return a * power * 4;
	} else {
		return a * power * 5;
	}
	
}
}
