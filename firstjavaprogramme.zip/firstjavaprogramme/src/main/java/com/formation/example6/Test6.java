package com.formation.example6;

public class Test6 {
	public static void main(String[] args) {
		String mot = "kayak1";
		StringBuffer sb = new StringBuffer(mot);
		
		sb.reverse();

		String inverse = sb.toString();
		
		
		if (mot.equals(inverse)) {
			System.out.println("this is a pallendrum");
	
		} else {
			System.out.println("this is NOT a pallendrum");

		} 
		}
}
