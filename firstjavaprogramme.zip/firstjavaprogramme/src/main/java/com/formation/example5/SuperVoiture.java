package com.formation.example5;

import com.formation.example2.UneVoiture;

// heritage de la classe UneVoiture
public class SuperVoiture extends UneVoiture {
	
	
}
