package com.formation.example5;

public class Test5 {
	public static void main(String[] args) {
		SuperVoiture sv = new SuperVoiture();
		
		int v = sv.vitesse(4);
		System.out.println(v);
}
}
