package com.formation.example2;

public class Entry2 {
	public static void main(String[] args) {
		//construction de la Voiture
		UneVoiture v1 = new UneVoiture();
		
		System.out.println("Puissance :" +v1.power);
		System.out.println("Color Before :" +v1.color);
		v1.color = "Brown";
		System.out.println("Color after :" +v1.color);
		
		UneVoiture v2 = new UneVoiture();
		System.out.println("Color V2 : "+v2.color);

	}
	
}
