package com.formation.example3;

//import de la classe qui n est dans dans la meme arboresecence
import com.formation.example2.UneVoiture;

public class Test3 {
	public static void main(String[] args) {

		UneVoiture v1 = new UneVoiture();
		UneVoiture v2 = new UneVoiture("Yellow",15,"Renault");
	System.out.println("Marque: " +v2.marque);
	System.out.println("Marque: " +v1.marque);
	
	v1.start();
	v1.stop();
	// fait appel au case de la valeur calculer la variable
	int v = v1.vitesse(2);
	System.out.println(v);
	}
	
}
