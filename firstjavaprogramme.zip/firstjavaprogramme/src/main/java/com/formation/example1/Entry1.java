package com.formation.example1;

public class Entry1 {

	public static void main(String[] args) {
		System.out.println("Hello **6666* World!!!");
	}
}
