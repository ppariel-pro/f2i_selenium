package com.formation.exo1;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebImplicitWait {

	public static void main(String[] args) throws InterruptedException {
		String chromeDriverPath = "C:\\temp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromeDriverPath);

		WebDriver driver = new ChromeDriver();
		
		Path sampleFile = Paths.get("pages/activity_5_A-1.html");
		driver.get(sampleFile.toUri().toString());
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		try {

			driver.findElement(By.id("runTestButton")).click();
			
			WebElement info = driver.findElement(By.id("lesson"));
			if (info.getText().contains("run")) {
				System.out.println("Implicit Wait works");
				
			} else {
				System.out.println("Implicit Wait NOT works");
			}
			
		} finally {

			driver.close();
		}
	}
}
