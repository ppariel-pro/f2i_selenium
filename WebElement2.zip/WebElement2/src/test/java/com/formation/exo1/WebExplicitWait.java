package com.formation.exo1;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebExplicitWait {

	public static void main(String[] args) throws InterruptedException {
		String chromeDriverPath = "C:\\temp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromeDriverPath);

    	WebDriver driver = new ChromeDriver();
		
		Path sampleFile = Paths.get("pages/activity_5_B-1.html");
		driver.get(sampleFile.toUri().toString());
		
		try {

			driver.findElement(By.id("runTestButton")).click();
			
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.titleContains("Explicit"))
			
			if (driver.getTitle()).startsWith("Explicit") {
				System.out.println("Explicit Wait works");
			} else {
				System.out.println("Explicit Wait DOESNTwork");
			}
			
		}
		
	}
}
