package com.formation.exo1;

import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class OverView_1 {
	public static void main(String[] args) throws InterruptedException {
		String chromeDriverPath = "C:\\temp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromeDriverPath);
		
		
		WebDriver driver = new ChromeDriver();
	
		try	{

		Path sampleFile = Paths.get("pages/activity-1.html");
		driver.get(sampleFile.toUri().toString());
		
		WebElement spanish = driver.findElement(By.id("spanish"));
		spanish.click();
		
		WebElement email = driver.findElement(By.id("inputEmail"));
		email.sendKeys("email@gmail.com");
		
		Thread.sleep(2000);
		if (email.getAttribute("value").equalsIgnoreCase("email@gmail.com")) {
			System.out.println("email OK ");
		} else {
			System.out.println("mauvais mail");
		};
	} finally 	{
		
  driver.close();
}
	}
}

