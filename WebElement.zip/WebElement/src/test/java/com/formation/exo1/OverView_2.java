package com.formation.exo1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.lang.reflect.Array;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class OverView_2 {

	public static void main(String[] args) throws InterruptedException {
		String chromeDriverPath = "C:\\temp\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromeDriverPath);

		WebDriver driver = new ChromeDriver();

		try {
			Path sampleFile = Paths.get("pages/activity-2.html");
			driver.get(sampleFile.toUri().toString());

			// Using id
			WebElement lastName = driver.findElement(By.id("lastName"));

			if (lastName.isDisplayed()) {
				System.out.println("lastname is visible");
			} else {
				System.out.println("Wrong lastName");
			}

			// using name

			WebElement hobbies = driver.findElement(By.name("hobbies"));
			if (hobbies.isDisplayed()) {
				System.out.println("hobbies is visible");
			} else {
				System.out.println("Wrong hobbies");
			}

			// using class name
			WebElement firstName = driver.findElement(By.className("form-control"));
			if (firstName.isDisplayed()) {
				System.out.println("firstname is visible");
			} else {
				System.out.println("Wrong firstname");
			}

			// using html tag
			List<WebElement> div = driver.findElements(By.tagName("div"));
			if (div.size() > 0) {
				System.out.println("more than 0 div ");
			} else {
				System.out.println("Wrong DIV");
			}

			// Using Link
			WebElement spanishlink = driver.findElement(By.linkText("Spanish"));
			String link = spanishlink.getAttribute("href");
			if (!"".equals(link)) {
				System.out.println("link is visible");
			} else {
				System.out.println("Wrong link");
			}

			// Using text Area
			WebElement textArea = driver.findElement(By.id("aboutYourself"));
			if (textArea.isEnabled() && textArea.isDisplayed()) {
				System.out.println("Text Area visible");

				// check text area empty
				if ("".equals(textArea.getAttribute("value")))
					System.out.println("Text Area IS empty");
			} else {
				System.out.println("Text Area NOT empty");
			}

			textArea.sendKeys("this is a sample text.");

			if ("this is a sample text.".equalsIgnoreCase(textArea.getAttribute("value"))) {
				System.out.println("Text Area IS well filled in");
			} else {
				System.out.println("Text Area IS NOT well filled in");
			}

			textArea.clear();
			if ("".equals(textArea.getAttribute("value"))) {
				System.out.println("Text Area IS cleaned");
			} else {
				System.out.println("Text Area IS NOT cleaned");
			}

			/*
			 * System.out.println("Default error : Text Area IS NOT Visible and displayed");
			 */
			// List choix multiple

			Select SingleChoiceList = new Select(driver.findElement(By.id("monthofBirth")));
			if (!SingleChoiceList.isMultiple() && SingleChoiceList.getOptions().size() == 13) {
				System.out.println(" 13 chooses avalaibles");
				SingleChoiceList.selectByVisibleText("February");
				if (SingleChoiceList.getFirstSelectedOption().getText().equalsIgnoreCase("February")) {
					System.out.println("February selected");

				} else {
					System.out.println("ERROR : February IS NOT selected");
				}

			} else {
				System.out.println("ERROR : Months IS NOT selected");
			}

			Select multipleChoiceList = new Select(driver.findElement(By.id("hobbies")));
			if (multipleChoiceList.isMultiple() && multipleChoiceList.getOptions().size() == 4) {
				System.out.println("TList contains 4 options");
				multipleChoiceList.selectByVisibleText("Reading");
				multipleChoiceList.selectByVisibleText("Sports");
				multipleChoiceList.selectByVisibleText("Traveling");

				multipleChoiceList.deselectByVisibleText("Sports");
				if (multipleChoiceList.getAllSelectedOptions().size() == 2) {
					System.out.println("2 Options choosen OK");
				} else {

					System.out.println("ERROR : Options ARE NOT 2");
				}
				
			List<String> expectedSelection =	Arrays.asList("Reading", "Traveling");
			List<String> actualSelection =	new ArrayList<String>();			
			
			for (WebElement element : multipleChoiceList.getAllSelectedOptions()) {
				actualSelection.add(element.getText());
			}
			if (actualSelection.containsAll(expectedSelection)) {
				System.out.println("OK expected element selected");
					
			} else {
				System.out.println("expected element selected IS KO");
			}

/*	} finally {
			driver.close();

			}
	*/		
		
	
}
		}
